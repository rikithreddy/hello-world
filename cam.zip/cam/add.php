

  <head	>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Sign Up Form</title>
        <link rel="stylesheet" href="css/normalize.css">
        <link href='http://fonts.googleapis.com/css?family=Nunito:400,300' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" href="css/main.css">
    </head>
    <body>

	<div style="float:right;width:500px">
	 <a href="index.php" > Logout </a> 
	 </div>
	 </br>
      <form action="#" method="post">
      
        <h1>To a add user  enter the following details</h1>
        
        <fieldset>
          <legend><span class="number">1</span>Login Details</legend>
          <label for="name"> Login ID: </label>
          <input type="text" id="name" name="name" required>
          
          <label for="mail">Role:</label>
		  <input type="radio" name="role" value="2" required><label for="tablet" class="light">Admin</label><br>
          <input type="radio" name="role" value="1"><label for="phone" class="light">User to Mark photos</label> <br>
          <br>
		  <br>
          <label for="name"> Password ( optional )</label>
          <input type="text" id="model" name="password" placeholder="password" required >
          
          
          
        </fieldset>
        
        
        <button type="submit">Submit</button>
      </form>
      
	  <br>
	 
	  
	  
    </body>
</html>




<?php
if (isset($_POST['name']))
{
	
	function Connection()
{
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "crowd";
	$conn = new mysqli($servername, $username, $password,$dbname);
	if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
			return null;
		} 
	return $conn;

}

$DeviceID=0;
$conn= Connection();

$sql="insert into login ( username,password,role ) values ('".$_POST['name']."','".$_POST['password']."',".$_POST['role']." )";
if(TRUE===$conn->query($sql))
{ }
else
	print $conn->error;

session_start();
$sql="select count(*) as ID from main";
$result=$conn->query($sql);

if($result->num_rows > 0)
	{
		$row=$result->fetch_assoc();
		$_SESSION['id']=$row["ID"];
	}
	//print "hi";
	
	
	

$_SESSION['snap']=0;





//header ("Location: ./works.php");

//$temp=0;
//$row = $result->fetch_assoc();			
//$DeviceID=$row["I"];
			
//$cookie_value = "";

//setcookie('DeviceID', $DeviceID, time() + (86400 * 365), "/"); 

}

?>




