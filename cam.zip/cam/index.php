<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="css/s1.css">


</head>
<body>

<h2>Crowd Sourcing</h2>
<br>
<br>

<a href="login.php"> <button class="button button1">Administrator</button> </a>
<a href="form.php"> <button class="button button2">User</button> </a>
<a href="login.php"> <button class="button button3">Mark Photos</button> </a>

</body>
</html>
