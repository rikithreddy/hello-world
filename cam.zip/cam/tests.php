
	<html>
	<div id="a" >
	a
	</div>

	<script>

	var d="c";
	var e=2;
	var b=10;
	var c=2;
	function kk(){
		window.alert('hi')
	} 
	</script>
	<script>
	function z(){
		
		
		var div;
		
		
		if(d=="a"){		
			var temp='a'+c+b;
			div = document.getElementById(temp).style.visibility='hidden';

			}
		else if(d=="b")
		{	
		var temp='b'+c+b;
			div = document.getElementById(temp).style.visibility='hidden';
				
			}		
		else if(d=="c") {
			var temp='c'+c+b;
			div = document.getElementById(temp).style.visibility='hidden';
			
		
		}
			else {
				
				window.alert("error"+d);
				}
		
		
			
		
		b = Math.floor(Math.random()*100);
		b%=8;
		c = Math.floor(Math.random()*100);
		c%=75;
		f = Math.floor(Math.random()*100);
		f%=2;
		e=(e+2)%3;
		
		if(e==0){
		
		var temp='a'+c+b;
			div = document.getElementById(temp).style.visibility = 'visible';
		d='a';
			window.alert(temp);
		
		}
		else if(e==1)
		{ 	

		//window.alert(e);
		
			d='b';
			var temp='c'+c+b;
			div = document.getElementById(temp).style.visibility = 'visible';
			window.alert(temp);
		
			}
			else {
		
			window.alert(e);
		

			d='c';
			var temp='c'+c+b;
			div = document.getElementById(temp).style.visibility = 'visible';
		
			}
		
		
		
	}
	</script>






	<?php 
	function a($ab,$b,$c){
		if($ab=="c" && $b==10 && $c==2)
		{
			

		}
	else 		echo "visibility:hidden";	
	}


	for($j=0;$j<=75;$j++) {
	for($i=0;$i<=8	;$i++)
	{ 


	?>
	<div id="<?php echo "a",$j,$i ?>" onclick="z();" style="background-color:red;min-height:20px;min-width:20px;max-height:20px;max-width:20px;float:left;<?php a('a',$j,$i)?>;" > &nbsp </div>



	<div id="<?php echo "c",$j,$i ?>" onclick="z();" style="background-color:green;min-height:20px;min-width:20px;max-height:20px;max-width:20px;float:left;<?php a('b',$j,$i)?>;" > &nbsp </div>


	<div id="<?php echo "c",$i,$j ?>" onclick="z();" style="background-color:blue;min-height:20px;min-width:20px;max-height:20px;max-width:20px0px;float:left;<?php a('c',$j,$i)?>;" > &nbsp </div>

	<?php 

		} 

		}


	?>


	</div >



	</html>
