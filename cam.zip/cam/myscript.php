    <?php
	session_start();
    
	function Connection()
{
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "crowd";
	$conn = new mysqli($servername, $username, $password,$dbname);
	if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
			return null;
		} 
	return $conn;

}


$conn= Connection();

	
	
	
	
	$encoded_data = $_POST['mydata'];
    $binary_data = base64_decode( $encoded_data );

	
	
	$sql="insert into units (id,number,X,Y,height,width) values (".$_SESSION['id'].",".($_SESSION['snap']).",".$_POST['x'].",".$_POST['y'].",".$_POST['h'].",".$_POST['w'].")";

		
		
	if(file_exists("images/".$_SESSION['id']))
	{
	
	
	
	$result=$conn->query($sql);
	$f=fopen("logs/myscript.log","a");
	
	fwrite($f,"test");	
	$result = file_put_contents( "images/".$_SESSION['id']."/".$_SESSION['snap'].".jpg", $binary_data );
	$_SESSION['snap']++;
	fwrite($f,$result."\n");

		}
	else 
	{
		$result=$conn->query($sql);

     	mkdir("images/".$_SESSION['id'], 0777, true);
		$result = file_put_contents( "images/" . $_SESSION['id'] . "/" . $_SESSION['snap'] . ".jpg", $binary_data );
		$_SESSION['snap']++;

		
		}
	
		


		
		
	
	