  <head	>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Sign Up Form</title>
        <link rel="stylesheet" href="css/normalize.css">
        <link href='http://fonts.googleapis.com/css?family=Nunito:400,300' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" href="css/main.css">
    </head>
    <body>

      <form action="#" method="post">
      
        <h1>LOGIN</h1>
        
        <fieldset>
          <label for="name">USER:</label>
          <input type="text" id="user" name="user" required>
          
          <br>
          <label for="name">PASSWORD:</label>
          <input type="password" id="password" name="password"  required>
          
          
          
        </fieldset>
        
        
        <button type="submit">Submit</button>
      </form>
      
    </body>
</html>

<?php 
	
function Connection()
{
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "crowd";
	$conn = new mysqli($servername, $username, $password,$dbname);
	if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
			return null;
		} 
	return $conn;

}

if(isset($_POST['user']))
{
	session_start();
	$conn= Connection();
	$sql="select role from login where username='".$_POST['user']."' and password='".$_POST['password']."'";
	echo $sql;
	$result=$conn->query($sql);
	$row=$result->fetch_assoc();
	$_SESSION['role']=$row['role'];
	if($_SESSION['role']==1)
	header("Location: ./mark.php");
	else if ($_SESSION['role']==2)
	header("Location: ./add.php");
	else
	header("Location: ./error.php");
	
}
?>


 