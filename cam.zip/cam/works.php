<?php 
	session_start(); 
	if(!isset($_SESSION['snap']))  
		$_SESSION['snap']=0; 
	$_SESSION['x']=rand(1,17); 
	$_SESSION['y']=rand(1,17);
	
	

?>

<html>
	<script src="jquery.min.js"></script>

	<?php if($_SESSION['snap']%5==0 || 1)
				{ ?>
	
				<script>
				var count=0;
				var d="c";
				var e=2;
				var b=<?php echo $_SESSION['y'];?>;
				var c=<?php echo $_SESSION['x'];?>;
	
				function kk(){
				
					//window.alert('hi')
				div = document.getElementById('c'+c+b).style.visibility='hidden';

				c = Math.floor(Math.random()*100);
				c=c%17;
				b = Math.floor(Math.random()*100);
				b=b%17;
				div = document.getElementById('c'+c+b).style.visibility='visible';
				var t=(b%8+1)+'.png';
				var m = "url('"+t+"')";
				//window.alert(m);
				div = document.getElementById('c'+c+b).style.backgroundImage=m;
				var elem = document.getElementById('c'+c+b);
				//window.alert('top -'+elem.offsetTop+'left -'+elem.offsetLeft)
				count++;
				if(count==5)
				{
					window.location.replace("thankyou.php");
				}
				
				} 
					
	</script>






	<?php 


	function a($ab,$b,$c){
		
		if($ab=="c" && $b==$_SESSION['x'] && $_SESSION['y']==$c)			
			echo "visibility:visible";	
		
		else 		
			echo "visibility:hidden";	

	}

	for($j=0;$j<=17;$j++) {
		for($i=0;$i<=17	;$i++)
		{ 
			?>

	<div id="<?php echo "c",$j,$i ?>" onclick="kk();" style=" background-size:100%;background-image:url('1.png');min-height:50px;min-width:50px;max-height:20px;max-width:20px;float:left;<?php a('c',$j,$i)?>;" > </div>


	<?php 

		} 

		}


	?>


	
<?php } ?>







  <script src="webcam.js"></script>
    <div id="my_camera" style="width:400px; height:300px;visibility:hidden;"></div>
    <div id="my_result"></div>
 <script language="JavaScript">
        Webcam.attach( '#my_camera' );
		function test(){
			take_snapshot();		
			}
		var a=0;
 
 
 
		var raw_image_data;
		function take_snapshot() {
		//window.alert('hi');	
		Webcam.snap( function(data_uri1) {
       raw_image_data = data_uri1.replace(/^data\:image\/\w+\;base64\,/, '');
        document.getElementById('mydata').value = raw_image_data;
			
		
	}
	);
		}
		
		
 		
	function pausecomp(millis)
{	
	//window.alert(1);	
    var date = new Date();
    var curDate = null;
	//window.alert(date);

    do { curDate = new Date(); 
	
	//window.alert(curDate-date);
	}
		
   while(curDate-date < millis);

			
					
   
   }
</script>



<script>

$(document).ready(function(){
	
	
    $("div").click(function(){

	
	
	
	
	//window.alert();
	for(i=0;i<3;i++)
	{
		take_snapshot();
	//	window.alert(raw_image_data);
        $.post("myscript.php",
        {
			
          mydata: raw_image_data,
          x : event.screenX,
		  y : event.screenY,
		  w : window.innerWidth,
		  h : window.innerHeight,
		  
        },
        function(data,status){
            a=2; 	
        });
    pausecomp(5);
	}
	});
});



</script>
    <form id="myform" method="post" action="myscript.php">
        <input id="mydata" type="hidden" name="mydata" value=""/>


		
	<?php //print rand(1,50); ?>
	</html>
s