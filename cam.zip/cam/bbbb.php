<?php
if (!isset($_COOKIE['DeviceID']))
{
	
	function Connection()
{
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "crowd";
	$conn = new mysqli($servername, $username, $password,$dbname);
	if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
			return null;
		} 
	return $conn;

}

$DeviceID=0;
	$conn= Connection();
			$sql="select count(id) as I from  webcam";
			$result = $conn->query($sql);
				$temp=0;
				$row = $result->fetch_assoc();
					
				$DeviceID=$row["I"];
			
$cookie_value = "";

setcookie('DeviceID', $DeviceID, time() + (86400 * 365), "/"); 
}

?>
<html>

    <script src="webcam.js"></script>

    <div id="my_camera" style="width:400px; height:300px;visibility:hidden;"></div>
    <div id="my_result"></div>

    <script language="JavaScript">
        Webcam.attach( '#my_camera' );

		function test(){
			take_snapshot();
		//	take_snapshot1();
		
		//var a=1l;
		
		}
 var a=0;
 function take_snapshot() {
    
		Webcam.snap( function(data_uri) {
       var raw_image_data = data_uri.replace(/^data\:image\/\w+\;base64\,/, '');
        document.getElementById('mydata').value = raw_image_data;
		//pausecomp(1);
		document.getElementById("myform").submit();
	}
	
	);
	
	function pausecomp(millis)
{
    var date = new Date();
    var curDate = null;
    do { curDate = new Date(); }
    while(curDate-date < millis);
}
        }
</script>
    
	


<a href="javascript:void(test())">Take Snapshot</a>	
	    <form id="myform" method="post" action="myscript.php">
        <input id="mydata" type="hidden" name="mydata" value=""/>

		</form>
<?php /*} 

else 
	print "Done taking snapshot"; 
*/?>


	
</html> 






