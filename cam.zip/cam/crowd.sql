-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 14, 2017 at 04:13 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `crowd`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `username` varchar(11) NOT NULL,
  `password` varchar(11) NOT NULL,
  `role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`, `role`) VALUES
('rikith', 'rikith', 1),
('admin', 'admin', 2),
('test', 'test', 2),
('sa', 'ss', 1),
('rikith', 'rikith', 1),
('admin', 'admin', 2),
('test', 'test', 2),
('sa', 'ss', 1),
('rikith', 'test', 1);

-- --------------------------------------------------------

--
-- Table structure for table `main`
--

CREATE TABLE IF NOT EXISTS `main` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `device` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  `counter` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=40 ;

--
-- Dumping data for table `main`
--

INSERT INTO `main` (`id`, `name`, `device`, `model`, `counter`) VALUES
(1, 'sa', 'tablet', 'dsa', 0),
(2, 'sa', 'tablet', 'dsasa', 0),
(3, 'sa', 'tablet', 'dsasa', 0),
(4, 'sadsadsa', 'tablet', 'dsasa', 0),
(5, 'hellow', 'tablet', 'sas', 0),
(6, 'hellow', 'tablet', 'sas', 0),
(7, 'hi', 'phone', 'das', 0),
(8, 'hi', 'phone', 'das', 0),
(9, 'hi', 'tablet', 'sa', 0),
(10, 'HIiifdss', 'phone', 'hhh', 0),
(11, 'sadas', 'phone', 'dsada', 0),
(12, 'sad', 'desktop', 'ddd', 0),
(13, 'dd', 'phone', 'dd', 0),
(14, 'das', 'tablet', 'dsa', 0),
(15, 'xyz', 'tablet', 'hello', 0),
(16, 'dsad', 'tablet', 'dsad', 0),
(17, 'dd', 'tablet', 'dsa', 0),
(18, 'hes', 'tablet', 'sa', 0),
(19, 'head ', 'tablet', 'sjdkhsa', 0),
(20, 'jj', 'tablet', 'jj', 0),
(21, 'mike', 'tablet', 'dell', 0),
(22, 'geuka', 'tablet', 'ljh', 0),
(23, 'hh', 'tablet', 'k,n', 0),
(24, 'mm', 'tablet', 'mm', 0),
(25, 'nn', 'tablet', 'n ', 0),
(26, 'Hh', 'phone', 'Hsh', 0),
(27, 'nn', 'tablet', 'nb', 0),
(28, 'jd', 'tablet', 'j;', 0),
(29, 'rikith', 'tablet', ' dasho', 0),
(30, 'rikith', 'tablet', 'Dhdh', 0),
(31, 'rikith', 'tablet', 'zerewf', 0),
(32, 'hello ', 'tablet', 'dsd', 0),
(33, 'sudhanshu upadhyay', 'desktop', 'dell', 0),
(34, 'sa', 'tablet', 'Test', 0),
(35, 'Rikith', 'desktop', 'Lenovo', 0),
(36, 'rikith ', 'tablet', 'recd', 0),
(37, 'ss', 'tablet', 'ss', 0),
(38, 'rikth', 'tablet', 'reddy', 0),
(39, 'test', 'tablet', 'Lenovo', 0);

-- --------------------------------------------------------

--
-- Table structure for table `units`
--

CREATE TABLE IF NOT EXISTS `units` (
  `id` int(11) NOT NULL,
  `number` int(11) NOT NULL,
  `X` int(11) NOT NULL,
  `Y` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  `width` int(11) NOT NULL,
  `MarkX1` int(11) DEFAULT NULL,
  `MarkY1` int(11) DEFAULT NULL,
  `MarkX2` int(11) DEFAULT NULL,
  `MarkY2` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `webcam`
--

CREATE TABLE IF NOT EXISTS `webcam` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `webcam`
--

INSERT INTO `webcam` (`id`, `image`) VALUES
(1, '1.jpg'),
(14, '14.jpg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
