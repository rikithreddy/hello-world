<html>
<?php
function Connection()
{
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "crowd";
	$conn = new mysqli($servername, $username, $password,$dbname);
	if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
			return null;
		} 
	return $conn;

}

$conn=Connection();
$sql="SELECT id,number FROM units where MarkX2 is NULL";
$result=$conn->query($sql);
$row=$result->fetch_assoc();

$id=$row['id'];
$num=$row['number'];




?>



<h1>
Mark the image:
</h1>
<div >

<canvas  id="myCanvas" width="300" height="300"  style="background: url('images/<?php print $id ?>/<?php print $num ?>.jpg') " >
Your browser does not support the HTML5 canvas tag.</canvas>


<!--

<img alt="no images left" src="images/<?php print $id ?>/<?php print $num ?>.jpg" >
</img>


-->


</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>


<script>

var cn=1;
var x1,y1;

$(document).ready(function(){
	
	
    $("div").click(function(){

	work();
	
	if(cn%3==0)
	{
	
		
	    $.post("markscript.php",
        {
          x : event.screenX,
		  y : event.screenY,
		  xx : x1,
		  yy : y1,
		  id : <?php print $id ?> ,
		  num : <?php print $num ?>
        },
        function(data,status){
            a=2; 	
        });
	location.reload();
	}
	
	
	});
});



</script>
<script>
var c = document.getElementById("myCanvas");
var ctx = c.getContext("2d");

var imageObj = new Image();
imageObj.src='2.jpg';



ctx.fillStyle = "#c82124"; //red
ctx.fill(); 


function work()
{
	
		

	cn=cn+1;

if(cn%2==0)
{
x1 = event.screenX;
y1= event.screenY;	
	
}
    var c = document.getElementById("myCanvas");
    var ctx = c.getContext("2d");

    var imageObj = new Image();

	
	ctx.fillStyle = "#c82124"; //red
	ctx.beginPath();
	ctx.arc(event.clientX-10,event.clientY-60,2,0,Math.PI*2,true);
	ctx.closePath();
	ctx.fill(); 
	
}


</script> 
<a href="index.php" > logout </a>
</html>
