    <?php
	session_start();
    
	function Connection()
{
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "crowd";
	$conn = new mysqli($servername, $username, $password,$dbname);
	if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
			return null;
		} 
	return $conn;

}


	$conn= Connection();

	
	
	
	

	$f=fopen("a.txt","w");
	
	$sql="Update units Set MarkX1=".$_POST['x']." , MarkY1=".$_POST['y']." , MarkX2=".$_POST['xx']." , MarkY2=".$_POST['yy'] ."   where id=".$_POST['id']." and number=".$_POST['num'];
	fwrite($f,$sql);
	
	
	$result=$conn->query($sql);
		
	
		


		
		
	
	?>